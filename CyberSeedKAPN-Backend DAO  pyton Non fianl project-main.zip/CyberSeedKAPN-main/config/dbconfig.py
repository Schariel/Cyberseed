pg_config = {
    'host' : 'ec2-3-226-163-72.compute-1.amazonaws.com',
    'user' : 'noqzbvgsuucpzr',
    'password' : '83c65e55501bea01e1129455fb2c55b6b67f32dc13694c53d104b79be34c3514',
    'dbname' : 'db988ljt61udo8',
    'dbport' : ' 5432'
}
