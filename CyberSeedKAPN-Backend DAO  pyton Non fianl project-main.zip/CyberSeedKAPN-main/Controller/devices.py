from flask import jsonify
from DAO.Devices import DevicesDAO
from datetime import datetime


class DevicesController:
    def build_map_dict(self, row):
        result = {}
        result['deviceid'] = row[0]
        result['userid'] = row[1]
        result['plantid'] = row[2]
        result['status'] = row[3]
        result['cdate'] = row[4]
        return result
    def build_attr_dict(self, deviceid, userid, plantid, status):
        result = {}
        result['deviceid'] = deviceid
        result['userid'] = userid
        result['plantid'] = plantid
        result['status'] = status
        return result

    def createDevice(self, json):
        if len(json) != 2:
            return jsonify(error='bad request'), 400
        userid = json['userid']
        plantid = json['plantid']
        dao = DevicesDAO()
        device = dao.addDevice(userid, plantid)
        return jsonify(device), 201

    def getAllUserDevices(self, userid):
        dao = DevicesDAO()
        device_list = dao.getAllUserDevices(userid)
        result = []
        for row in device_list:
            device = self.build_map_dict(row)
            result.append(device)
        return jsonify(devices=result), 200

    def getDevice(self, deviceid):
        dao = DevicesDAO()
        device = dao.getDeviceById(deviceid)
        return jsonify(device=device)

    def updateDeviceUser(self, deviceid, userid):
        dao = DevicesDAO()
        device = dao.getDeviceById(deviceid)
        if not device:
            return jsonify(error='Not Found'), 404
        # if device[1] != userid:
        #     return jsonify(error='User not Owner'), 500
        else:
            device = dao.updateDeviceUser(deviceid)
            return jsonify(device), 201

    def updateDevicePlant(self, deviceid, plantid):
        dao = DevicesDAO()
        device = dao.getDeviceById(deviceid)
        if not device:
            return jsonify(error='Not Found'), 404
        # elif device[1] != plantid:
        #     return jsonify(error='Plant not Owner'), 500
        else:
            device = dao.updateDevicePlant(deviceid, plantid)
            return jsonify(device), 201

    def updateDeviceStatus(self, deviceid, status):
        dao = DevicesDAO()
        device = dao.getDeviceById(deviceid)
        if not device:
            return jsonify(error='Not Found'), 404
        else:
            device = dao.updateDeviceStatus(deviceid, status )
            return jsonify(device), 201

    def deleteDevice(self, deviceid):
        return self.updateDeviceStatus(deviceid, "OFF")

    def removeDevicePlant(self, deviceid, plantid):
        dao = DevicesDAO()
        result = dao.removeDevicePlant(deviceid, plantid)
        if result:
            return jsonify("Plant has been remove"), 200
        else:
            return jsonify("Not found"), 404

    def removeDeviceUser(self, deviceid, userid):
        dao = DevicesDAO()
        result = dao.removeDeviceUser(deviceid, userid)
        if result:
            return jsonify("User has been remove"), 200
        else:
            return jsonify("Not found"), 404
