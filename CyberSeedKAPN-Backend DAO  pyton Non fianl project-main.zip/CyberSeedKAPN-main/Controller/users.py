from flask import jsonify
from DAO.Users import UsersDAO


class UserController:
    def build_map_dict(self, row):
        result = {}
        result['userid'] = row[0]
        result['username'] = row[1]
        result['firstname'] = row[2]
        result['lastname'] = row[3]
        result['email'] = row[4]
        result['password'] = row[5]
        result['phone'] = row[6]
        result['cdate'] = row[7]
        return result

    def build_attr_dict(self, userid, username, firstname, lastname, email, password, phone):
        result = {}
        result['userid'] = userid
        result['username'] = username
        result['firstname'] = firstname
        result['lastname'] = lastname
        result['email'] = email
        result['password'] = password
        result['phone'] = phone
        return result

    def addUser(self, json):
        username = json['username']
        firstname = json['firstname']
        lastname = json['lastname']
        email = json['email']
        password = json['password']
        phone = json['phone']
        dao = UsersDAO()
        uid = dao.addUser(username, firstname, lastname, email, password, phone)
        if uid == -1:
            return jsonify("Username or Email already in use!")
        result = self.build_attr_dict(uid,  username, firstname, lastname, email, password, phone)
        return jsonify(result), 201

    def getUserById(self, userid):
        dao = UsersDAO()
        user_tuple = dao.getUserById(userid)
        if not user_tuple:
            return jsonify("User not found."), 404
        else:
            result = self.build_map_dict(user_tuple)
            return jsonify(result), 200

    def loginUser(self,credential,password):
        dao = UsersDAO()
        user_login = dao.loginUser(credential, password)
        if not user_login:
            return -1
        else:
            return jsonify(user_login), 200

    def updateUser(self, json, uid):
        username = json['username']
        firstname = json['firstname']
        lastname = json['lastname']
        email = json['email']
        password = json['password']
        phone = json['phone']
        dao = UsersDAO()
        updated = dao.updateUser(uid, username, firstname, lastname, email, password, phone)
        result = self.build_attr_dict(uid, username, firstname, lastname, email, password, phone)
        return jsonify(result), 200

    def deleteUser(self, userid, json):
        dao = UsersDAO()
        result = dao.deleteUser(userid, json["credential"], json["pass"])
        if result:
            return jsonify("User has been deleted"), 200
        else:
            return jsonify("Not found"), 404
