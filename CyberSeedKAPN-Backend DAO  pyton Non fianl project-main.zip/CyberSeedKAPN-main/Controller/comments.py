from flask import jsonify
from DAO.Comments import CommentsDAO
from datetime import datetime


class CommentsController:
    def build_map_dict(self, row):
        result = {}
        result['commentid'] = row[0]
        result['entryid'] = row[0]
        result['userid'] = row[1]
        result['message'] = row[2]
        result['cdate'] = row[3]
        return result

    def build_attr_dict(self, commentid, entryid, userid, message):
        result = {}
        result['commentid'] = commentid
        result['entryid'] = entryid
        result['userid'] = userid
        result['message'] = message
        return result


    def addComment(self, userid, entryid, json):
        message = json['message']
        dao = CommentsDAO()
        commentid = dao.addComment(entryid, userid, message)
        return jsonify(commentid), 201

    def getEntryComments(self, entryid):
        dao = CommentsDAO()
        comment_tuple = dao.getComments(entryid)
        if not comment_tuple:
            return jsonify("Comment not found."), 404
        else:
            result = self.build_map_dict(comment_tuple)
            return jsonify(result), 200

    def deleteComment(self, commentid):
        dao = CommentsDAO()
        result = dao.deleteComment(commentid)
        if result:
            return jsonify("Comment has been deleted"), 200
        else:
            return jsonify("Not found"), 404