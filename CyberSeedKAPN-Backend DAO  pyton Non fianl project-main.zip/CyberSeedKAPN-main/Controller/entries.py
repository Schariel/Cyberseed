from flask import jsonify
from DAO.Entries import EntriesDAO


class EntriesController:
    def build_map_dict(self, row):
        result = {}
        result['entryid'] = row[0]
        result['plantid'] = row[1]
        result['ph'] = row[2]
        result['uv'] = row[3]
        result['humidity'] = row[4]
        result['temperature'] = row[5]
        result['cdate'] = row[6]
        return result

    def build_attr_dict(self, entryid, plantid, ph, uv, humidity, temperature):
        result = {}
        result['entryid'] = entryid
        result['plantid'] = plantid
        result['ph'] = ph
        result['uv'] = uv
        result['humidity'] = humidity
        result['temperature'] = temperature
        return result

    def addEntries(self, plantid, json):
        if len(json) != 4:
            return jsonify(error="Invalid Input"), 400
        ph = json['ph']
        uv = json['uv']
        humid = json['humidity']
        temp = json['temperature']
        dao = EntriesDAO()
        entryid = dao.addEntry(plantid, ph, uv, humid, temp)
        if entryid == -1:
            return jsonify("Username or Email already in use!")
        result = self.build_attr_dict(entryid,plantid, ph, uv, humid, temp)
        return jsonify(Success=result), 201

    def getEntryById(self, entryid):
        dao = EntriesDAO()
        entry = dao.getEntryById(entryid)
        if not entry:
            return jsonify("Entry not found."), 404
        else:
            result = self.build_map_dict(entry)
            return jsonify(Entry=result), 200

    def getAllPlantEntries(self, plantid):
        dao = EntriesDAO()
        entries = dao.getAllPlantEntries(plantid)
        result = []
        for row in entries:
            entry = self.build_map_dict(row)
            result.append(entry)
        return jsonify(Entries=result), 200



