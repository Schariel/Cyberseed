from flask import jsonify
from DAO.Plants import PlantsDAO


class PlantsController:
    def build_map_dict(self, row):
        result = {}
        result['pid'] = row[0]
        result['name'] = row[1]
        result['type'] = row[2]
        result['min_ph'] = row[3]
        result['max_ph'] = row[4]
        result['min_uv'] = row[5]
        result['max_uv'] = row[6]
        result['min_humid'] = row[7]
        result['max_humid'] = row[8]
        result['min_temperature'] = row[9]
        result['max_temperature'] = row[10]
        result['additive'] = row[11]
        result['birthdate'] = row[12]
        result['batch_number'] = row[13]
        result['cdate'] = row[14]
        return result

    def build_attr_dict(self, pid, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid,min_temperature, max_temperature, additive, birthdate, batch_number):
        result = {}
        result['pid'] = pid
        result['name'] = name
        result['type'] = type
        result['min_ph'] = min_ph
        result['max_ph'] = max_ph
        result['min_uv'] = min_uv
        result['max_uv'] = max_uv
        result['min_humid'] = min_humid
        result['max_humid'] = max_humid
        result['min_temperature'] = min_temperature
        result['max_temperature'] = max_temperature
        result['additive'] = additive
        result['birthdate'] = birthdate
        result['batch_number'] = batch_number
        return result

    def addPlant(self, json):
        name = json['name']
        type = json['type']
        min_ph = json['min_ph']
        max_ph = json['max_ph']
        min_uv = json['min_uv']
        max_uv = json['max_uv']
        min_humid = json['min_humid']
        max_humid = json['max_humid']
        min_temperature = json['min_temperature']
        max_temperature = json['max_temperature']
        additive = json['additive']
        birthdate = json['birthdate']
        batch_number = json['batch_number']
        dao = PlantsDAO()
        pid = dao.addPlant(name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temperature, max_temperature, additive, birthdate, batch_number)
        if pid == -1:
            return jsonify("Plant Name already in use!")
        result = self.build_attr_dict(pid, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temperature, max_temperature, additive, birthdate, batch_number)
        return jsonify(result), 201

    def getPlantById(self, pid):
        dao = PlantsDAO()
        plant_tuple = dao.getPlantById(pid)
        if not plant_tuple:
            return jsonify("Plant not found."), 404
        else:
            result = self.build_map_dict(plant_tuple)
            return jsonify(result), 200

    def updatePlant(self, json, pid):
        name = json['name']
        type = json['type']
        min_ph = json['min_ph']
        max_ph = json['max_ph']
        min_uv = json['min_uv']
        max_uv = json['max_uv']
        min_humid = json['min_humid']
        max_humid = json['max_humid']
        min_temperature = json['min_temperature']
        max_temperature = json['max_temperature']
        additive = json['additive']
        birthdate = json['birthdate']
        batch_number = json['batch_number']
        dao = PlantsDAO()
        updated = dao.updatePlant(pid, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temperature, max_temperature, additive, birthdate, batch_number)
        result = self.build_attr_dict(pid, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temperature, max_temperature, additive, birthdate, batch_number)
        return jsonify(result), 200

    def deletePlant(self, pid):
        dao = PlantsDAO()
        result = dao.deletePlant(pid)
        if result:
            return jsonify("Plant has been deleted"), 200
        else:
            return jsonify("Not found"), 404
