from flask import Flask, request, jsonify
from flask_cors import CORS
from Controller.users import UserController
from Controller.comments import CommentsController
from Controller.devices import DevicesController
from Controller.entries import EntriesController
from Controller.plants import PlantsController

app = Flask(__name__)
# apply CORS
CORS(app)


@app.route('/')
def hello_world():
    return 'Hello World!'


@app.route('/users', methods=['POST'])
def add_user():
    if request.method == 'POST':
        print(request.json)
        return UserController().addUser(request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/users/<int:userid>', methods=['GET', 'PUT', 'DELETE'])
def handle_user_by_id(userid):
    if request.method == 'GET':
        return UserController().getUserById(userid)
    elif request.method == 'PUT':
        return UserController().updateUser(request.json, userid)
    elif request.method == 'DELETE':
        return UserController().deleteUser(userid, request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/users/<int:userid>/entries/<int:entryid>/comments', methods=['POST'])
def handle_comments(userid, entryid):
    if request.method == 'POST':
        return CommentsController().addComment(userid, entryid, request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/entries/<int:entryid>/comments', methods=['GET'])
def get_entry_comments(entryid):
    if request.method == 'GET':
        return CommentsController().getEntryComments(entryid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/comments/<int:commentid>', methods=['DELETE'])
def delete_comment(commentid):
    if request.method == 'DELETE':
        return CommentsController().deleteComment(commentid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/plants', methods=['POST'])
def add_plant():
    if request.method == 'POST':
        print(request.json)
        return PlantsController().addPlant(request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/plants/<int:plantid>', methods=['GET', 'PUT', 'DELETE'])
def handle_plant(plantid):
    if request.method == 'GET':
        return PlantsController().getPlantById(plantid)
    elif request.method == 'PUT':
        return PlantsController().updatePlant(request.json, plantid)
    elif request.method == 'DELETE':
        return PlantsController().deletePlant(plantid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/plants/<int:plantid>/entries', methods=['GET', 'POST'])
def handle_entries(plantid):
    if request.method == 'POST':
        return EntriesController().addEntries(plantid, request.json)
    elif request.method == 'GET':
        return EntriesController().getAllPlantEntries(plantid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/entries/<int:entryid>', methods=['GET'])
def get_entry(entryid):
    if request.method == 'GET':
        return EntriesController().getEntryById(entryid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/devices', methods=['POST'])
def add_device():
    if request.method == 'POST':
        return DevicesController().createDevice(request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/users/<int:userid>/devices', methods=['GET'])
def get_user_devices(userid):
    if request.method == 'GET':
        return DevicesController().getAllUserDevices(userid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/devices/<int:deviceid>', methods=['DELETE'])
def handle_user_device(deviceid):
    if request.method == 'DELETE':
        return DevicesController().deleteDevice(deviceid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/devices/<int:deviceid>', methods=['GET'])
def handle_device(deviceid):
    if request.method == 'GET':
        return DevicesController().getDevice(deviceid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/devices/<int:deviceid>/plants/<int:plantid>', methods=['PUT'])
def update_device_plant(deviceid, plantid):
    if request.method == 'PUT':
        return DevicesController().updateDevicePlant(deviceid, plantid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/devices/<int:deviceid>/users/<int:userid>', methods=['PUT'])
def update_device_user(deviceid, userid):
    if request.method == 'PUT':
        return DevicesController().updateDeviceUser(deviceid, userid)
    else:
        return jsonify("Method Not Allowed"), 405


if __name__ == '__main__':
    app.run()
