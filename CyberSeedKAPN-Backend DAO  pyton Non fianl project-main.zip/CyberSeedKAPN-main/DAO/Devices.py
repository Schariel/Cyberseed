from config.dbconfig import pg_config
import psycopg2

'''
Devices Schema Attributes:
    Device Id 
    User Id
    Plant Id
    Status -> Pending (User only), Active (User & Plant), Deactivated(Plant only), OFF (None)
    Creation Date
'''

class DevicesDAO:
    def __init__(self):
        connection_url = "dbname=%s user=%s password=%s port=%s host=%s" % (
        pg_config['dbname'], pg_config['user'],
        pg_config['password'], pg_config['dbport'], pg_config['host'])
        print("conection url:  ", connection_url)
        self.conn = psycopg2.connect(connection_url)
        # self.conn = psycopg2.connect(dbname=pg_config['dbname'],)

    def addDevice(self, userid, plantid):
        cursor = self.conn.cursor()
        query = "insert into devices (userid, plantid, status, cdate) values (%s,%s, 'ACTIVE', now()) returning deviceid;"
        cursor.execute(query, (userid, plantid,))
        did = cursor.fetchone()[0]
        self.conn.commit()
        self.verifyDeviceStatus(did)
        return did

    def getAllUserDevices(self, userid):
        cursor = self.conn.cursor()
        query = "select deviceid, userid, plantid, status, cdate from devices where deviceid = %s;"
        cursor.execute(query, (userid,))
        result = cursor.fetchall()
        return result

    def getDeviceById(self, deviceid):
        cursor = self.conn.cursor()
        query = "select deviceid, userid, plantid, status, cdate from devices where deviceid = %s;"
        cursor.execute(query, (deviceid,))
        result = cursor.fetchone()
        return result

    def updateDevicePlant(self, deviceid, plantid):
        cursor = self.conn.cursor()
        query = "update devices set plantid=%s where deviceid=%s;"
        cursor.execute(query, (plantid,deviceid,))
        self.conn.commit()
        return self.verifyDeviceStatus(deviceid)

    def updateDeviceUser(self, deviceid, userid):
        cursor = self.conn.cursor()
        query = "update devices set userid=%s where deviceid=%s;"
        cursor.execute(query, (userid, deviceid,))
        self.conn.commit()
        return self.verifyDeviceStatus(deviceid)

    def updateDeviceStatus(self, deviceid, status):
        cursor = self.conn.cursor()
        query = "update devices set status=%s where deviceid=%s;"
        cursor.execute(query, (status, deviceid,))
        self.conn.commit()
        return self.verifyDeviceStatus(deviceid)

    def verifyDeviceStatus(self, deviceid):
        device = self.getDeviceById(deviceid)
        plantid, userid, status = device[1], device[2], device[3]

        if plantid and userid and status != "ACTIVE":
            cursor = self.conn.cursor()
            query = "update devices set status='ACTIVE' where deviceid=%s;"
            cursor.execute(query, (deviceid,))
            self.conn.commit()
        elif (not plantid) and (not userid) and status != "OFF":
            cursor = self.conn.cursor()
            query = "update devices set status='OFF' where deviceid=%s;"
            cursor.execute(query, (deviceid,))
            self.conn.commit()
        elif (not plantid) and userid and status != "PENDING":
            cursor = self.conn.cursor()
            query = "update devices set status='PENDING' where deviceid=%s;"
            cursor.execute(query, (deviceid,))
            self.conn.commit()
        elif plantid and (not userid) and status != "DEACTIVE":
            cursor = self.conn.cursor()
            query = "update devices set status='PENDING' where deviceid=%s;"
            cursor.execute(query, (deviceid,))
            self.conn.commit()
        return True

    def removeDeviceUser(self, deviceid, userid):
        cursor = self.conn.cursor()
        query = "delete from devices set userid=%s where deviceid=%s;"
        cursor.execute(query, (deviceid, userid,))
        self.conn.commit()
        return self.verifyDeviceStatus(deviceid)

    def removeDevicePlant(self, deviceid, plantid):
        cursor = self.conn.cursor()
        query = "delete from devices set plantid=%s where deviceid=%s;"
        cursor.execute(query, (plantid,))
        self.conn.commit()
        return self.verifyDeviceStatus(deviceid)
