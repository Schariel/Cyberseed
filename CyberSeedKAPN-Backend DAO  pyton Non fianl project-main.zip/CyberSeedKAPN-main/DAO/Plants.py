from config.dbconfig import pg_config
import psycopg2

'''
Plants Schema Attributes:
    Plant Id 
    Plant Name
    Plant Type
    Min PH
    Max PH
    Min UV
    Max UV
    Min Humidity
    Max Humidity
    Min Temp
    Max Temp
    Additive (Text)
    Birthdate  (Current Date - Birthdate = Plant Age)
    Batch Number
    Creation Date
'''

class PlantsDAO:
    def __init__(self):
        connection_url = "dbname=%s user=%s password=%s port=%s host=%s" % (
        pg_config['dbname'], pg_config['user'],
        pg_config['password'], pg_config['dbport'], pg_config['host'])
        print("conection url:  ", connection_url)
        self.conn = psycopg2.connect(connection_url)
        # self.conn = psycopg2.connect(dbname=pg_config['dbname'],)

    def addPlant(self, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temp, max_temp, additive, birthdate, batch_number):
        cursor = self.conn.cursor()
        query = "Select * from plants where name=%s;"
        cursor.execute(query, (name,))
        plant = cursor.fetchone()
        if plant is None:
            query = "insert into plants (name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temp, max_temp, additive, birthdate, batch_number, cdate) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now()) returning plantid;"
            cursor.execute(query, (name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temp, max_temp, additive, birthdate, batch_number,))
            plantid = cursor.fetchone()[0]
            self.conn.commit()
            return plantid
        else:
            return -1

    def getPlantById(self, plantid):
        cursor = self.conn.cursor()
        query = "select plantid, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temp, max_temp, additive, birthdate, batch_number, cdate from plants where plantid = %s;"
        cursor.execute(query, (plantid,))
        result = cursor.fetchone()
        return result

    def updatePlant(self, plantid, name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temp, max_temp, additive, birthdate, batch_number):
        cursor = self.conn.cursor()
        query = "update plants set name=%s, type=%s, min_ph=%s, max_ph=%s, min_uv=%s, max_uv=%s, min_humid=%s, max_humid=%s, min_temp=%s, max_temp=%s, additive=%s birthdate=%s, batch_number=%s where plantid=%s;"
        cursor.execute(query, (name, type, min_ph, max_ph, min_uv, max_uv, min_humid, max_humid, min_temp, max_temp, additive, birthdate, batch_number, plantid))
        self.conn.commit()
        return True

    def deletePlant(self, plantid):
        cursor = self.conn.cursor()
        query = "delete from plants where plantid=%s;"
        cursor.execute(query, (plantid,))
        # determine affected rows
        affected_rows = cursor.rowcount
        self.conn.commit()
        # if affected rows == 0, the part was not found and hence not deleted
        # otherwise, it was deleted, so check if affected_rows != 0
        return affected_rows != 0
