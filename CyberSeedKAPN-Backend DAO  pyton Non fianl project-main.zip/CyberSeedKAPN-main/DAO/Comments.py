from config.dbconfig import pg_config
import psycopg2

'''
Comments Schema Attributes:
    Comment Id
    Entry Id 
    User Id
    message
    Creation Date
'''

class CommentsDAO:
    def __init__(self):
        connection_url = "dbname=%s user=%s password=%s port=%s host=%s" % (
        pg_config['dbname'], pg_config['user'],
        pg_config['password'], pg_config['dbport'], pg_config['host'])
        print("conection url:  ", connection_url)
        self.conn = psycopg2.connect(connection_url)
        # self.conn = psycopg2.connect(dbname=pg_config['dbname'],)

    def addComment(self, entryid, userid, message):
        cursor = self.conn.cursor()
        query = "insert into COMMENTS (entryid, userid, message, cdate) values (%s,%s,%s,now()) returning commentid;"
        cursor.execute(query, (entryid, userid, message))
        commentid = cursor.fetchone()[0]
        self.conn.commit()
        return commentid

    def getEntryComments(self, entryid):
        cursor = self.conn.cursor()
        query = "select commentid, entryid, userid, message, cdate from COMMENTS where entryid = %s;"
        cursor.execute(query, (entryid,))
        entries = []
        for row in cursor:
            entries.append(row)
        return entries

    def deleteComment(self, commentid, userid):
        cursor = self.conn.cursor()
        query = "delete from COMMENTS where commentid=%s and userid=%s;"
        cursor.execute(query, (commentid, userid))
        # determine affected rows
        affected_rows = cursor.rowcount
        self.conn.commit()
        # if affected rows == 0, the part was not found and hence not deleted
        # otherwise, it was deleted, so check if affected_rows != 0
        return affected_rows != 0
