from config.dbconfig import pg_config
import psycopg2

'''
Entries Schema Attributes:
    Entry Id 
    Plant Id
    PH
    UV
    Humidity
    Temperature
    Creation Date
'''

class EntriesDAO:
    def __init__(self):
        connection_url = "dbname=%s user=%s password=%s port=%s host=%s" % (
        pg_config['dbname'], pg_config['user'],
        pg_config['password'], pg_config['dbport'], pg_config['host'])
        print("conection url:  ", connection_url)
        self.conn = psycopg2.connect(connection_url)
        # self.conn = psycopg2.connect(dbname=pg_config['dbname'],)

    def addEntry(self, pid, ph, uv, humid, temp):
        cursor = self.conn.cursor()
        query = "insert into ENTRIES (plantid, ph, uv, humidity, temperature, cdate) values (%s,%s,%s,%s,%s, now()) returning entryid;"
        cursor.execute(query, (pid, ph, uv, humid, temp))
        entryid = cursor.fetchone()[0]
        self.conn.commit()
        return entryid

    def getEntryById(self, entryid):
        cursor = self.conn.cursor()
        query = "select entryid, plantid, ph, uv, humidity, temperature, cdate from ENTRIES where entryid = %s;"
        cursor.execute(query, (entryid,))
        result = cursor.fetchone()
        return result

    def getAllPlantEntries(self, plantid):
        cursor = self.conn.cursor()
        query = "select entryid, plantid, ph, uv, humidity, temperature, cdate from ENTRIES where plantid=%s;"
        cursor.execute(query, (plantid,))
        entries = []
        for row in cursor:
            entries.append(row)
        return entries
