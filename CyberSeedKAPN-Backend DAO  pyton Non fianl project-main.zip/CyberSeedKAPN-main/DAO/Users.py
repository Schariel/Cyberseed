from config.dbconfig import pg_config
import psycopg2

'''
Users Schema Attributes:
    User Id 
    Username
    First Name 
    Last Name 
    Email 
    Phone
    Creation Date
    Password
'''

class UsersDAO:
    def __init__(self):
        connection_url = "dbname=%s user=%s password=%s port=%s host=%s" % (
        pg_config['dbname'], pg_config['user'],
        pg_config['password'], pg_config['dbport'], pg_config['host'])
        print("conection url:  ", connection_url)
        self.conn = psycopg2.connect(connection_url)
        # self.conn = psycopg2.connect(dbname=pg_config['dbname'],)

    def addUser(self, username, firstname, lastname, email, password, phone):
        cursor = self.conn.cursor()
        check = "select * from users where username = %s or email = %s;"
        cursor.execute(check, (username, email,))
        found = cursor.fetchone()
        if found is None:
            query = "insert into users (username, firstname, lastname, email, pass, phone, cdate) values (%s,%s,%s,%s,%s,%s,now()) returning userid;"
            cursor.execute(query, (username, firstname, lastname, email, password, phone))
            userid = cursor.fetchone()[0]
            self.conn.commit()
            return userid
        else:
            return "Already Exists"

    def getUserById(self, userid):
        cursor = self.conn.cursor()
        query = "select userid, username, firstname, lastname, email, pass, phone, cdate from users where userid = %s;"
        cursor.execute(query, (userid,))
        result = cursor.fetchone()
        return result

    def loginUser(self, credential, password):
        cursor = self.conn.cursor()
        check = "select userid, username, firstname, lastname, email, pass, phone, cdate from users where (username = %s or email = %s) and password = %s;"
        cursor.execute(check, (credential, credential, password,))
        found = cursor.fetchone()
        if found:
            return found
        return -1

    def updateUser(self, userid, username, firstname, lastname, email, password, phone):
        cursor = self.conn.cursor()
        query = "update users set username=%s, firstname=%s, lastname=%s, email=%s, pass=%s, phone=%s where userid=%s;"
        cursor.execute(query, (username, firstname, lastname, email, password, phone, userid,))
        self.conn.commit()
        return True

    def deleteUser(self, userid, credential, password):
        cursor = self.conn.cursor()
        query = "delete from users where userid=%s and (username = %s or email = %s) and pass = %s;"
        cursor.execute(query, (userid, credential, credential, password))
        # determine affected rows
        affected_rows = cursor.rowcount
        self.conn.commit()
        # if affected rows == 0, the part was not found and hence not deleted
        # otherwise, it was deleted, so check if affected_rows != 0
        return affected_rows != 0
