from flask import Flask, request, jsonify
from flask_cors import CORS
from Controller.users import UserController
from Controller.comments import CommentsController
from Controller.devices import DevicesController
from Controller.entries import EntriesController
from Controller.plants import PlantsController

app = Flask(__name__)
# apply CORS
CORS(app)


@app.route('/')
def hello_world():
    return 'Hello World'


@app.route('/api/users', methods=['POST'])
def handleUser():
    if request.method == 'POST':
        return UserController().addUser(request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/users/<int:uid>', methods=['GET', 'PUT', 'DELETE'])
def handleUserById(uid):
    if request.method == 'GET':
        return UserController().getUserById(uid)
    elif request.method == 'PUT':
        return UserController().updateUser(request.json, uid)
    elif request.method == 'DELETE':
        return UserController().deleteUser(uid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/comments/<int:cid>', methods=['DELETE'])
def handleCommentsById(cid):
    if request.method == 'DELETE':
        return CommentsController().deleteComment(cid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/<int:eid>/comments', methods=['POST', 'GET'])
def handleComments(eid):
    if request.method == 'POST':
        return CommentsController().addComment(request.json)
    elif request.method == 'GET':
        return CommentsController().getEntryComments(eid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/plants', methods=['POST'])
def handlePlant():
    if request.method == 'POST':
        return PlantsController().addPlant(request.json)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/plants/<int:pid>', methods=['GET', 'PUT', 'DELETE'])
def handlePlantById(pid):
    if request.method == 'GET':
        return PlantsController().getPlantById(pid)
    elif request.method == 'PUT':
        return PlantsController().updatePlant(request.json, pid)
    elif request.method == 'DELETE':
        return PlantsController().deletePlant(pid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/<int:pid>/entries', methods=['GET', 'POST'])
def handleEntries(pid):
    if request.method == 'POST':
        return EntriesController().addEntries(request.json)
    elif request.method == 'GET':
        return EntriesController().getAllPlantEntries(pid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/entries/<int:eid>', methods=['GET'])
def handleEntriesById(eid):
    if request.method == 'GET':
        return EntriesController().getEntryById(eid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/devices', methods=['GET', 'POST'])
def handleDevice(did):
    if request.method == 'POST':
        return DevicesController().createDevice(request.json)
    elif request.method == 'GET':
        return DevicesController().getAllUserDevices(did)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/devices/<int:did>', methods=['GET', 'DELETE'])
def handleDevicesById(did):
    if request.method == 'GET':
        return DevicesController().getDevice(did)
    elif request.method == 'DELETE':
        return DevicesController().deleteDevice(did)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/devices/<int:did>/plants/<int:pid>', methods=['PUT'])
def handleDevicesPlantsById(did, pid):
    if request.method == 'PUT':
        return DevicesController().updateDevicePlant(request.json, pid)
    else:
        return jsonify("Method Not Allowed"), 405


@app.route('/api/devices/<int:did>/users/<int:uid>', methods=['PUT'])
def handleDevicesUsersById(did, uid):
    if request.method == 'PUT':
        return DevicesController().updateDeviceUser(request.json, uid)
    else:
        return jsonify("Method Not Allowed"), 405


if __name__ == '__main__':
    app.run()
